
// Define Translations
var translation = [
    {
        "name":"english",
        "months":["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        "weekdays":["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        "rain":"Rain"
    },
    {
        "name":"german",
        "months":["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"],
        "weekdays":["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"],
        "rain":"Regen"
    }
]

// Set Options Values
document.documentElement.style.setProperty('--primary-color', primaryColor)
document.documentElement.style.setProperty('--secondary-color', secondaryColor)
document.documentElement.style.setProperty('--widget-top', topInset + "px")
document.documentElement.style.setProperty('--widget-inset', sideInset + "px")
// Check Language Exists (Bypass XenHTML Bug)
if (typeof language == 'undefined') {
    language = 0
}

// Function called by XenInfo when reloading widget
function mainUpdate(type){
    if (type == "weather") {
        document.getElementById("temperature").innerHTML = weather.temperature + "°";
        document.getElementById("weatherDescription").innerHTML = weather.condition
        document.getElementById("changeOfRain").innerHTML = translation[language].rain + ": " + weather.chanceofrain + "%"
        document.getElementById("weatherIcon").style.backgroundImage = "url('images/weather/" + getWeatherCode(weather.conditionCode) + ".png')"
    } else if(type == "statusbar"){
        document.getElementById("wifi").style.backgroundImage = "url('images/wifi/" + wifiBars + ".png')"
        document.getElementById("cellular").style.backgroundImage = "url('images/cellular/" + signalBars + ".png')"
    } else if(type == "battery"){
        document.getElementById("batteryPercentage").innerHTML = batteryPercent + "%"
        document.getElementById("ram").innerHTML = "RAM: " + Math.round((ramFree / ramPhysical) * 100) + "%"
    }
    document.getElementById("date").innerHTML = returnDate()
    document.getElementById("time").innerHTML = returnTime()
    if (enableApps) {
        document.getElementById("appsTitle").innerHTML = "Apps:"
    }
}

// Function to get the date in the format: Weekday Month Day
function returnDate() {
    let date = new Date()
    return translation[language].weekdays[date.getDay()] + " " + translation[language].months[date.getMonth()] + " " + date.getDate().toString()
}

// Function to get the current 24 hour time
function returnTime() {
    let date = new Date()
    let hours = date.getHours().toString()
    if (hours.length < 2) {
        hours = 0 + hours
    }
    let minutes = date.getMinutes().toString()
    if (minutes.length < 2) {
        minutes = 0 + minutes
    }
    return hours + ":" + minutes
}

// Function to convert condtionCode into something useful
function getWeatherCode(conditionCode) {
    if (conditionCode < 5) {
        return "storm"
    } else if (conditionCode < 11) {
        return "rain"
    } else if (conditionCode < 13) {
        return "light-rain"
    } else if (conditionCode == 13) {
        return "light-snow"
    } else if (conditionCode == 14) {
        return "medium-snow"
    } else if (conditionCode < 17) {
        return "heavy-snow"
    } else if (conditionCode < 25) {
        return "wind"
    } else if (conditionCode < 29) {
        return "mostly-cloudy"
    } else if (conditionCode < 31) {
        return "partly-cloudy"
    } else if (conditionCode < 33) {
        return "sun"
    } else if (conditionCode < 35) {
        return "fair"
    } else if (conditionCode < 37) {
        return "rain"
    } else if (conditionCode < 40) {
        return "partly-cloudy"
    } else if (conditionCode = 40) {
        return "rain"
    } else if (conditionCode < 44) {
        return "heavy-snow"
    } else if (conditionCode == 44) {
        return "partly-cloudy"
    } else if (conditionCode == 45) {
        return "storm"
    } else if (conditionCode == 46) {
        return "medium-snow"
    } else if (conditionCode == 47) {
        return "storm"
    } 
}