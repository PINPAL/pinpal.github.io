// Set Options Values
document.documentElement.style.setProperty('--bgColor', bgColor)
document.documentElement.style.setProperty('--topColor', topColor)
document.documentElement.style.setProperty('--bottomColor', bottomColor)
document.documentElement.style.setProperty('--topInset', topInset + "px")