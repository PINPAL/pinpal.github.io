// Define Translations
var translation = [
    {
        "name":"english",
        "months":["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        "its":"it's",
        "on":"on"
    },
    {
        "name":"german",
        "months":["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"],
        "its":"es ist",
        "on":"auf"
    }
]

// Set Options Values
document.documentElement.style.setProperty('--fontColor', fontColor)
document.documentElement.style.setProperty('--topInset', topInset + "px")
document.documentElement.style.setProperty('--image', "url('" + image + "')")

// Check Language Exists (Bypass XenHTML Bug)
if (typeof language == 'undefined') {
    language = 0
}

// Function called by XenInfo when reloading widget
function mainUpdate(type){
    if(type == "battery"){
        document.getElementById("batPercent").innerHTML = batteryPercent + "%"
        document.getElementById("batSliderInner").style.width = batteryPercent + "%"
    }
    // Clock and Date
    document.getElementById("date").innerHTML = returnDate()
    document.getElementById("time").innerHTML = translation[language].its + " " + returnTime()
}

// Function to get the date
function returnDate() {
    let date = new Date()
    return translation[language].on + " " + getDate() + " " + translation[language].months[date.getMonth()] + " '" + (date.getYear() - 100);
}

function getDate() {
    let date = new Date()
    date = date.getDate().toString()
    if (date.length < 2) {
        date = 0 + date
    }
    return date
}

// Function to get the current 12 hour time
function returnTime() {
    var date = new Date()
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    hours = hours.toString()
    if (hours.length < 2) {
        var hours = 0 + hours
    }
    minutes = minutes.toString()
    if (minutes.length < 2) {
        minutes = 0 + minutes
    }
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}